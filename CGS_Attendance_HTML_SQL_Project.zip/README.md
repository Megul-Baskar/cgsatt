# Cauvery Global School Attendance Portal

HTML/CSS frontend + Python Flask backend + SQL database.

## Run on Windows
1. Install Python 3.10+.
2. Open PowerShell in this folder.
3. Run `python -m venv .venv`
4. Run `.venv\\Scripts\\Activate.ps1`
5. Run `pip install -r requirements.txt`
6. Set your own first Creator credentials:
   `$env:CREATOR_USERNAME="your_new_creator_username"`
   `$env:CREATOR_PASSWORD="a-new-strong-password"`
   `$env:SECRET_KEY="a-long-random-secret"`
7. Run `python app.py`
8. Open http://127.0.0.1:5000

## Render deployment
Create a Render Web Service from your private GitHub repository.
Build command: `pip install -r requirements.txt`
Start command: `gunicorn app:app`
Runtime: Python.
Set `SECRET_KEY`, `CREATOR_USERNAME`, and `CREATOR_PASSWORD` in Render's environment settings. Add a managed PostgreSQL database and set `DATABASE_URL` to its internal connection URL. Do not rely on temporary SQLite storage for permanent attendance.

## Safety and privacy
This is a starter project, not a school-approved production system. Obtain school approval before using real student information. Keep the GitHub repository private. Never upload passwords, `.env` files, database files, real student lists or attendance exports. Use new unique credentials, strong secrets, backups and an approved persistent database. Have a school administrator review access controls and applicable student-data rules. Password reset, audit logs, bulk import and parent access are not included yet.
