import os
from datetime import date
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app=Flask(__name__)
app.config["SECRET_KEY"]=os.environ.get("SECRET_KEY","replace-before-deployment")
url=os.environ.get("DATABASE_URL","sqlite:///attendance.db")
if url.startswith("postgres://"): url=url.replace("postgres://","postgresql://",1)
app.config["SQLALCHEMY_DATABASE_URI"]=url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"]=False
db=SQLAlchemy(app)

class User(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    username=db.Column(db.String(80),unique=True,nullable=False)
    full_name=db.Column(db.String(120),nullable=False)
    password_hash=db.Column(db.String(255),nullable=False)
    role=db.Column(db.String(20),nullable=False)
    class_name=db.Column(db.String(40))
    def set_password(self,p): self.password_hash=generate_password_hash(p)
    def check_password(self,p): return check_password_hash(self.password_hash,p)

class Attendance(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    student_id=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False)
    marked_by=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False)
    attendance_date=db.Column(db.Date,nullable=False,default=date.today)
    status=db.Column(db.String(12),nullable=False)
    note=db.Column(db.String(250))
    student=db.relationship("User",foreign_keys=[student_id])
    __table_args__=(db.UniqueConstraint("student_id","attendance_date",name="unique_student_day"),)

with app.app_context():
    db.create_all()
    cu,cp=os.environ.get("CREATOR_USERNAME"),os.environ.get("CREATOR_PASSWORD")
    if cu and cp and not User.query.filter_by(username=cu).first():
        u=User(username=cu,full_name="Website Creator",role="creator"); u.set_password(cp)
        db.session.add(u); db.session.commit()

def me(): return db.session.get(User,session.get("uid")) if session.get("uid") else None
def require(*roles):
    def deco(fn):
        @wraps(fn)
        def inner(*a,**k):
            u=me()
            if not u: return redirect(url_for("login"))
            if roles and u.role not in roles:
                flash("You do not have permission to access that page.","error")
                return redirect(url_for("dashboard"))
            return fn(*a,**k)
        return inner
    return deco
@app.context_processor
def context(): return {"logged_user":me(),"today":date.today()}
@app.route("/")
def home(): return redirect(url_for("dashboard") if me() else url_for("login"))
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=User.query.filter_by(username=request.form.get("username","").strip()).first()
        if u and u.check_password(request.form.get("password","")) and u.role==request.form.get("role"):
            session.clear(); session["uid"]=u.id
            flash("Welcome, "+u.full_name+".","success")
            return redirect(url_for("dashboard"))
        flash("Login details or selected access control are incorrect.","error")
    return render_template("login.html")
@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("login"))
@app.route("/dashboard")
@require()
def dashboard():
    u=me()
    if u.role in ("creator","admin"):
        users=User.query.order_by(User.role,User.full_name).all()
        records=Attendance.query.order_by(Attendance.attendance_date.desc()).limit(25).all()
        return render_template("dashboard.html",users=users,records=records)
    if u.role=="teacher":
        students=User.query.filter_by(role="student").order_by(User.full_name).all()
        records=Attendance.query.order_by(Attendance.attendance_date.desc()).limit(25).all()
        return render_template("dashboard.html",students=students,records=records)
    records=Attendance.query.filter_by(student_id=u.id).order_by(Attendance.attendance_date.desc()).all()
    return render_template("dashboard.html",records=records)
@app.route("/accounts",methods=["GET","POST"])
@require("creator","admin")
def accounts():
    actor=me()
    allowed=["admin","teacher","student"] if actor.role=="creator" else ["teacher","student"]
    if request.method=="POST":
        name=request.form.get("full_name","").strip()
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        role=request.form.get("role","")
        if not name or not username or len(password)<10 or role not in allowed:
            flash("Complete all fields, choose an allowed role and use a password of at least 10 characters.","error")
        elif User.query.filter_by(username=username).first():
            flash("That username is already in use.","error")
        else:
            u=User(full_name=name,username=username,role=role,class_name=request.form.get("class_name","").strip() or None)
            u.set_password(password); db.session.add(u); db.session.commit()
            flash("Account created.","success"); return redirect(url_for("accounts"))
    return render_template("accounts.html",users=User.query.order_by(User.role,User.full_name).all(),allowed=allowed)
@app.route("/attendance",methods=["GET","POST"])
@require("creator","admin","teacher")
def attendance():
    students=User.query.filter_by(role="student").order_by(User.full_name).all()
    if request.method=="POST":
        try:
            sid=int(request.form["student_id"]); day=date.fromisoformat(request.form["attendance_date"])
        except (ValueError,KeyError): flash("Choose a valid student and date.","error"); return redirect(url_for("attendance"))
        student=db.session.get(User,sid); status=request.form.get("status")
        if not student or student.role!="student" or status not in ("Present","Absent","Late"):
            flash("Invalid attendance entry.","error")
        else:
            r=Attendance.query.filter_by(student_id=sid,attendance_date=day).first()
            if r: r.status=status; r.note=request.form.get("note","")[:250]; r.marked_by=me().id
            else: db.session.add(Attendance(student_id=sid,marked_by=me().id,attendance_date=day,status=status,note=request.form.get("note","")[:250]))
            db.session.commit(); flash("Attendance saved.","success"); return redirect(url_for("dashboard"))
    return render_template("attendance.html",students=students)
@app.errorhandler(404)
def missing(e): return render_template("error.html"),404
if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)))
